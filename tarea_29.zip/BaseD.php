<?php

    function insertDB($tabla,$into,$values){
        include ("conexion.php");
        try{
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql="INSERT INTO $BDName.$tabla($into) VALUES ($values);";
            $conn->exec($sql);
            return $conn->lastInsertId();
        }
        catch(PDOException $e){
            echo $sql . "<br>" . $e->getMessage();
        }
        $conn=null;
    }

    function ObtenerProducto($idproducto){
        include ("conexion.php");
        try{
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $query="SELECT * FROM $BDName.producto where idproducto='$idproducto'";
            $getUsers = $conn->prepare($query);
            $getUsers->execute();
            $users = $getUsers->fetch();
            return $users;
        }
        catch(PDOException $e){
            echo "Error: " . $e->getMessage();
        }
        $conn=null;

        return 0;
    }
    
    
    function modifyDB($tabla,$into,$values){
        include ("conexion.php");
        try{
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql="UPDATE $BDName.$tabla SET $into WHERE ($values);";
           
            $conn->exec($sql);
        }
        catch(PDOException $e){
            echo $sql . "<br>" . $e->getMessage();
        }
        $conn=null;
    }

    function deleteDB($tabla, $condicion){
        include ("conexion.php");
        try{
            //DELETE FROM `bd_carritocompras`.`carrito` WHERE (`idusuario` = '1') and (`idproducto` = '1');
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql="DELETE FROM $BDName.$tabla WHERE $condicion;";
            $conn->exec($sql);
        }
        catch(PDOException $e){
            echo $sql . "<br>" . $e->getMessage();
        }
        $conn=null;
    }

    function getuser($usuariocehck, $contracheck){
        include ("conexion.php");
        try{
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $query="SELECT * FROM $BDName.user where user='$usuariocehck' and pass='$contracheck'";
            $getUsers = $conn->prepare($query);
            $getUsers->execute();
            $users = $getUsers->fetchAll();
            foreach ($users as $user) {
                $usuario = $user['user'];
                $contra = $user['pass'];
                if($usuario == "admin"){
                    return 100;
                }
                return $user['confirmacion'];
            }
        }
        catch(PDOException $e){
            echo "Error: " . $e->getMessage();
        }
        $conn=null;

        return 0;
    }
    
    function getuserRegistro($usuariocehck){
        include ("conexion.php");
        try{
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $query="SELECT * FROM $BDName.user where user='$usuariocehck'";
            $getUsers = $conn->prepare($query);
            $getUsers->execute();
            $users = $getUsers->fetchAll();
            foreach ($users as $user) {
                $usuario = $user['user'];
                $contra = $user['pass'];
                if($usuario == "admin"){
                    return 100;
                }
                return $user['confirmacion'];
            }
        }
        catch(PDOException $e){
            echo "Error: " . $e->getMessage();
        }
        $conn=null;

        return 0;
    }

    function ObtenerUsuario($usuario){
        include ("conexion.php");
        try{
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $query="SELECT * FROM $BDName.user where user='$usuario'";
            $getUsers = $conn->prepare($query);
            $getUsers->execute();
            $users = $getUsers->fetch();
           
                return $users;
            }
        
        catch(PDOException $e){
            echo "Error: " . $e->getMessage();
        }
        $conn=null;

        return 0;
    }

    function getiduser($iduser){
        include ("conexion.php");
        try{
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            for($i=2;$i<100;$i++){
                $query="SELECT * FROM $BDName.user where idusuario=$i";
                $getUsers = $conn->prepare($query);
                $getUsers->execute();
                $users = $getUsers->fetchAll();
                foreach ($users as $user) {
                    $usuario=$user['nombre'];
                    if($iduser==$usuario){
                        return $user['idusuario'];
                    }
                }
            }
        }
        catch(PDOException $e){
            echo "Error: " . $e->getMessage();
        }
        $conn=null;
    }

    function verprod(){
        include ("conexion.php");
        try{
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $query="SELECT * FROM $BDName.producto where status='A'";
            $getdatos = $conn->prepare($query);
            $getdatos->execute();
            $datos = $getdatos->fetchAll();
            foreach ($datos as $dato) {
                echo '<form name="main" method="post" action="main.php">';
                echo ' <input type="submit" value="Agregar al carrito" name="agregar">';
                echo ' <input type="hidden" value="'.$dato['idproducto'].'" name="idprod">';
                echo '<img src="imagenes/'.$dato['foto'].'" class="produc"><br>';
                echo $dato['nombre'];
                echo "<br>";
                echo $dato['descripcion'];
                echo "<br>";
                echo "Cantidad:".$dato['cantidad']."<br>";
                echo "$".$dato['precio']."<br>", "<br>", "<br>";
               
                echo '</form>';
               
            }
        }
        catch(PDOException $e){
            echo "Error: " . $e->getMessage();
        }
        $conn=null;
    }

    function verusuarios(){
        include ("conexion.php");
        try{
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $query="SELECT * FROM $BDName.user ";
            $getdatos = $conn->prepare($query);
            $getdatos->execute();
            $datos = $getdatos->fetchAll();
            return $datos;
        }
        catch(PDOException $e){
            echo "Error: " . $e->getMessage();
        }
        $conn=null;
    }

    function ObtenerCarrito($idUsuario){
        include ("conexion.php");
        try{
            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $query="SELECT c.*, p.nombre,p.descripcion, p.foto 
            FROM $BDName.carrito c
            inner join $BDName.producto p on c.idproducto =p.idproducto 
            where c.idusuario=1 and c.status='A' ";
            $getdatos = $conn->prepare($query);
            $getdatos->execute();
            $datos = $getdatos->fetchAll();
            return $datos;
        }
        catch(PDOException $e){
            echo "Error: " . $e->getMessage();
        }
        $conn=null;
    }
?>