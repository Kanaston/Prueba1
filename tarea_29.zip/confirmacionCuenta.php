<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="imagenes/electronicc.png" type="image/png">
        <title>Confirmación Cuenta</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                <input type="text" class=titulo placeholder="Buscar articulo...">
            </header>
            <article>
                <h1>Iniciar Sesión</h1>
                <form name="LogIn" method="post" action="confirmacionCuenta.php">
                    <label>Usuario:</label>
                    <input type="text" name="user" id="user" value="<?php echo $_GET["user"]; ?>" required><br><br>
                    <label>Código Confirmación:</label>
                    <input type="text" name="confirma" id="confirma" required><br><br>
                    <input type="submit" value="Aceptar" class="boton" name="aceptar">
                    <input type="button" value="Volver" class="boton" onclick="volvermain()">
                </form>
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>

<?php
    if(isset($_POST["aceptar"])){
        include('BaseD.php');

        $confirmacion = getuserRegistro($_POST["user"]);
        if($confirmacion==1){
            echo"<script>
               alert('Bienvenido administrador');
               window.location='main.php';
            </script> ";
            
        }
		if ($confirmacion == $_POST["confirma"]){
			//modificar el registro del usuario poniendo 1 al campo confirmacion
			$tabla= "user";
            $into ="confirmacion = 1";
            $values = "user='".$_POST['user']."'";
            modifyDB($tabla,$into,$values);


            $mensaje = ''; // se guarda en mensaje el texto que quieras mostrar
            echo '<script>
                window.location="login.php?Message=" . urlencode($mensaje)";
            </script>';
			//mostrar mensaje alert y redireccionar al login
			//echo '<script> 
              //  alert("Usuario confirmado. Ya puede iniciar sesión.");
            //</script>';
			//header("location:login.php");
            exit();
			
			//si no jala poner mensaje en pantalla (sin mostrar formulario) 
		}
    }
?>