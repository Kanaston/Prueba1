<?php
    session_start();
    if(!isset($_SESSION["usuario"])){
         echo "<script> window.location='error.php';
       </script>";
    }
    include('BaseD.php');
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="electronicc.png" type="image/png">
        <title>Registro</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="Anotación 2020-03-21 115312.png" class="logo"></a>
                <input type="text" class=titulo placeholder="Buscar articulo...">
            </header>
            <article>
                <h1>Modificar usuario</h1>
                <form class="" action="configurarUser.php" method="post" id="main">
                    <strong><label for="">Contraseña:</label></strong><br>
                    <input type="password" id="pass" name="pass1" required pattern="^[A-Za-z0-9\.+-*_:;,¿¡?!|°]+$" minlength="8"
                    title="Combinar letras, al menos un número, al menos un símbolo especial, al menos 8 caracteres">
                    <br>
                    <input type="checkbox" id="checpass" onchange="mostrarpass()">Mostrar Contraseña
                    <br><br>
                    <strong><label for="">Nombre:</label></strong><br>
                    <input type="text" id="user" name="nom" required pattern="^[A-Za-z ]+$" maxlength="35" minlength="1"
                    title="Solo letras"><br><br>
                    <strong><label for="">Correo electronico:</label></strong><br>
                    <input type="text" id="email" name="correo" required pattern="^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$" maxlength="35" minlength="6"><br><br>
                    <strong><label for="">Edad:</label></strong><br>
                    <input type="text" id="edad" name="age" required><br><br>
                    <br>
                    <input type="submit" value="Confirmar" name="confirmar">
                    <input type="reset" value="Reset" name="confirma">
                </form>
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>

<?php
    if(isset($_POST["confirmar"])){
        $valor=$_COOKIE["iduser"];;
        $tabla="user";
        $into="'pass'='".$_POST['pass1']."','nombre'='".$_POST['nom']."','email'='".$_POST['correo']."','edad'='".$_POST['age']."'";
        $values="'idusuario'='".$valor."'";
        modifyDB($tabla,$into,$values);
        echo "<script> window.location='main.php';
        </script>";
    }
    
?>