<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <title>Contacto</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                <input type="text" class=titulo placeholder="Buscar articulo...">
            </header>
            <article>
                <h1>Distribuidora La máquina</h1>
                <p>Domicilio<br>Ciudad: Guadalajara, Jalisco<br>Colonia: Siempre viva, Bruselas #123, CP: 81230<br>Tel:2415369870</p><br><br> 
                <form action="contacto.php" method="post">
                    <label>Nombre:</label>
                    <input type="text" id="nam" required pattern="^[A-Za-z ]+$" maxlength="35" minlength="1"
                    title="Solo letras y espacios"><br><br>
                    <label>Correo electronico</label>
                    <input type="email" id="mail" required title="Se debe de ingresar un correo valido"><br><br>
                    <label>Mensaje:</label><br>
                    <textarea id="men" cols="30" rows="10" style="resize: none;" minlength="1" required></textarea><br><br>
                    <input type="button" value="Enviar" onclick="mostrar()" class="boton">
                    <input type="reset" value="Cancelar" class="boton">
                </form>    
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="login.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" 
                style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>
<?php
    if(isset($_POST["enviar"])){
    $destino="zabdiel_hiram@hotmail.com";
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $mensaje = $_POST["mensaje"];
    $contenido = "Nombre: ". $nombre . "\nCorreo: ". $correo .  "\nMensaje: " . $mensaje;
    mail($destino,"Contacto", $contenido);
    }

?>

