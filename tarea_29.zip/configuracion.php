<?php
    session_start();
    if(!isset($_SESSION["usuario"])){
        echo '<script>
        window.location="error.php";
    </script>';
    }
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="electronicc.png" type="image/png">
        <title>Configuración</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div id="cuerpo">
            <header id="cabeza">
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                <input type="text" class=titulo placeholder="Buscar articulo...">
                <div class="usuario">
                    <?php
                        $var=checar();
                        if($var==1){
                            logeado();
                        }
                        else{
                            sinlog();
                        }
                    ?>
                </div>
            </header>
            <article>
                <form method="post" action="configuracion.php">
                    <label id="letrasize">Tamaño de la fuente</label><br>
                    <input type="radio" name="tamanioletra" id="size1" value="Chico" onclick="chico()">Texto Chico<br>
                    <input type="radio" name="tamanioletra" id="size2" value="Mediano" onclick="mediano()" checked>Texto Mediano<br>
                    <input type="radio" name="tamanioletra" id="size3" value="Grande" onclick="grande()">Texto Grande<br>
                    <label>Cambiar el color del fondo</label><br>
                    <input type="color" name="fondo" id="colfondo" onchange="colorfondo()"><br>
                    <label id="letracolor">Cambiar el color de la letra</label><br>
                    <input type="color" name="letra" id="colletra" onchange="colorletra()"><br>
                    <label>Cambiar el color del header y footer</label><br>
                    <input type="color" name="cabeza" id="pie" onchange="colpies()"><br>
                    <input type="submit" value="Guardar" name="save">
                    <input type="submit" value="Reset" name="delete">
                </form>    
            </article>
            <footer id="pies">
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.html" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
            <script src="validar.js" charset="utf-8"></script>
        </div>
    </body>
</html>

<?php
    if(checar()==1){
        if(!empty($_COOKIE["usuario".$_SESSION["usuario"]])){
            if(!empty($_COOKIE["letra".$_SESSION["usuario"]])){
                switch($_COOKIE["letra".$_SESSION["usuario"]]){
                    case "Chico":?>
                        <style>
                            article{
                                font-size: 10px;
                            }
                        </style>
                        <?php
                    break;
                    case "Mediano":?>
                        <style>
                            article{
                                font-size: 20px;
                            }
                        </style>
                        <?php
                    break;
                    case "Grande":?>
                        <style>
                            article{
                                font-size: 30px;
                            }
                        </style>
                        <?php
                    break;
                }
            }
            if(!empty($_COOKIE["fondo".$_SESSION["usuario"]])){?>
                <style>
                    body{
                        background-color: <?php echo $_COOKIE["fondo".$_SESSION["usuario"]] ?>;
                    }
                </style>
                <?php
            }
            if(!empty($_COOKIE["colletra".$_SESSION["usuario"]])){?>
                <style>
                    body{
                        color: <?php echo $_COOKIE["colletra".$_SESSION["usuario"]] ?>;
                    }
                </style>
                <?php
            }
            if(!empty($_COOKIE["header".$_SESSION["usuario"]])){?>
                <style>
                    header{
                        background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                    }
                    footer{
                        background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                    }
                </style>
                <?php
            }
        }
    }
?>

<?php
    function checar(){
        if (isset($_SESSION["usuario"])){
            return 1;
        }
        else{
            return 0;
        }
    }
?>

<?php
    function logeado(){
        echo "Bienvenido ".$_SESSION["usuario"]; ?>
        <a href="carrito.php"><img src="carrito.png" style="width:40px; heigth:28px" class="carrito"></a>
    <?php
    }
?>

<?php
    function sinlog(){
    ?>
        <a href="registro.php" class="enlace">Registrarse</a>
        <a href="login.php" class="enlace">Iniciar Sesión</a>
    <?php
    }
?>

<?php
    if(isset($_POST["save"])){
        $letra=$_POST["tamanioletra"];
        $col_fondo=$_POST["fondo"];
        $col_letra=$_POST["letra"];
        $col_headfoot=$_POST["cabeza"];
        setcookie("letra".$_SESSION["usuario"],$letra,time()+ (86400 * 30),"/");
        setcookie("fondo".$_SESSION["usuario"],$col_fondo,time()+ (86400 * 30),"/");
        setcookie("colletra".$_SESSION["usuario"],$col_letra,time()+ (86400 * 30),"/");
        setcookie("header".$_SESSION["usuario"],$col_headfoot,time()+ (86400 * 30),"/");
        header("refresh:0");
    }
        
    
    if(isset($_POST["delete"])){
        if(!empty($_COOKIE["usuario".$_SESSION["usuario"]])){
            setcookie("letra".$_SESSION["usuario"],"",-time()+ (86400 * 30),"/");
            setcookie("fondo".$_SESSION["usuario"],"",-time()+ (86400 * 30),"/");
            setcookie("colletra".$_SESSION["usuario"],"",-time()+ (86400 * 30),"/");
            setcookie("header".$_SESSION["usuario"],"",-time()+ (86400 * 30),"/");
        }
    }
?>