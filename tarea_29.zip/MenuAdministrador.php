<?php
    session_start();
    include('BaseD.php');
    if(!isset($_SESSION["usuario"])){
          echo "<script> window.location='error.php';
             </script>";
    }
    elseif($_SESSION["usuario"]!=="admin"){
       echo "<script> window.location='main.php';
             </script>";
    }
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="electronicc.png" type="image/png">
        <title>Menú de usuarios</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
             <input type="text" class=titulo placeholder="Buscar articulo...">
            </header>
            <article>
                <form action="MenuAdministrador.php" method="post">
                    <input type="submit" value="Agregar Usuario" name="adduser"><br>
               
                    <!--Aqui c mostrara los usuarios en una tabla bien mamalona(segun yo xd)-->
                    <div class="algo">
                    <table border="1">
                    <tr>
                        <th>Id Usuario</th>
                        <th>Usuario</th>
                        <th>Contraseña</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Edad</th>
                        <th>Estatus</th>
                    </tr>
                    <?php
              
              $usuarios = verusuarios();

              foreach ($usuarios as $user) {
            
                echo "<tr>
                        <td>".$user['idusuario']."</td>
                        <td>".$user['user']."</td>
                        <td>".$user['pass']."</td>
                        <td>".$user['nombre']."</td>
                        <td>".$user['email']."</td>
                        <td>".$user['edad']."</td>
                        <td>".$user['estatus']."</td>
                        <td><a href='EliminarUsuario.php?id=".$user["idusuario"]."'>
                        <img src='imagenes/Eliminar2.jpg' width='50' height='50'>
                        </a></td>
                        <td><a href='ModificarUsuario.php?id=".$user["idusuario"]."'>
                        <img src='imagenes/modificar.jpg' width='50' height='50'>
                        </a></td>
                    </tr>";}
                    ?>
                    </table>
                    </div>
                </form>
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>

<?php
    if(isset($_POST["confuser"])){
        if(!empty($_POST['number'])){
            setcookie("iduser", $_POST['number'], time() + (86400 * 30));
            echo "<script> window.location='ConfigurarUser.php';
             </script>";
        }
    }
    if(isset($_POST["confadmin"])){
         if(!empty($_POST['number'])){
          echo "<script> window.location='ConfigurarAdmin.php';
       </script>";
         }
    }
    if(isset($_POST["adduser"])){
         echo "<script> window.location='registro.php';
         </script>";
        
    }
    if(isset($_POST["deleteuser"])){
        $tabla="user";
        $into="status='B'";
        $values="idusuario='".$_POST['number']."'";
    }
 ?>
