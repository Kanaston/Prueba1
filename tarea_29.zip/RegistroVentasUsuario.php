<?php
/* By http://php-estudios.blogspot.com */

/* PARTE 1: AL INICIO SE EXTRAEN TODAS LAS FILAS */
//Necesitamos establecer una conexión con la base de datos.
include("conexion.php");
//Datos de conexión
$con=mysqli_connect($Server,$User,$Pass,$BDName)or die ("problemas al conectar");

//Seleccionar la base datos y la conexión y capturar posibles errores con die


//Preparar la consulta para extraer todos los clientes
$consulta = "SELECT * FROM ventas";

//Ejecutar la consulta
$resultado = mysqli_query($con, $consulta) or die(mysqli_error());

//Extraer todas la filas y almacenarlas en una tabla
$table = "<table border='1' cellpadding='10' style='text-align:center; margin: 0 auto'>\n";
$table .= "<tr><th>ID ventas</th><th>ID usuario</th><th>Precio total</th><th>Fecha</th>
<th>Modificacion</th><th>Estatus</th>\n";
while($fila = mysqli_fetch_assoc($resultado)){
$table .= "<tr>
      <td>".$fila["idventas"]."</td>
      <td>".$fila["idusuario"]."</td>
      <td>".$fila["preciototal"]."</td>
      <td>".$fila["fecha"]."</td>
      <td>".$fila["modificacion"]."</td>
      <td>".$fila["estatus"]."</td>
    
   </tr>\n";
    }
$table .= "</table>\n";

    /* Cerrar la conexión */
    mysqli_close($con); 
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="imagenes/electronicc.png" type="image/png">
        <title>Comercial Network</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                <p>Registro de ventas</p>
                 
            </article>
            <footer>
              
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
          
                
            </footer>
        </div>
            <?php
                /* Mostrar la tabla con los registros */
                echo $table;
            ?>
        <a href="main.php" style="margin: 650px; font-size: 30px;" >Regresar</a>

        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>




