<?php
  session_start();
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="imagenes/electronicc.png" type="image/png">
        <title>Iniciar Sesion</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        
<?php
  
    if (isset($_GET['Message'])) {
        	echo '<script> 
                alert("Usuario confirmado. Ya puede iniciar sesión.");
            </script>';
         }
    if(isset($_POST["aceptar"])){
        include('BaseD.php');
        getuser($_POST["user"], $_POST["pass"]);
        $confirmacion = getuser($_POST["user"], $_POST["pass"]);    
        if($_POST["user"] == "admin" && $_POST["pass"]=="admin"){
            echo '<script> 
                alert("Bienvenido administrador");
                window.location="main.php";
            </script>';;
            $_SESSION["usuario"]=$_POST["user"];
        }
       
        else if($confirmacion != 1 && $confirmacion != 100) {
              echo '<script>
                  window.location="confirmacionCuenta.php?user='.$_POST["user"].'";
                    </script>';
            //header("location:confirmacionCuenta.php?user=".$_POST[get_current_user("user")]);
            exit();
        } else {
            $_SESSION["usuario"]=$_POST["user"];
            $check=$_POST["salvar"];
            switch($check){
                case "saveusu":
                    setcookie("radioCarShopPHP", $check, time() + (86400 * 30));
                    setcookie("usuarioCarShopPHP", $_POST["user"], time() + (86400 * 30));
                    break;
                case "saveusupass":
                    setcookie("radioCarShopPHP", $check, time() + (86400 * 30));
                    setcookie("usuarioCarShopPHP", $_POST["user"], time() + (86400 * 30));
                    setcookie("contraCarShopPHP", $_POST["pass"], time() + (86400 * 30));
                    break;
            }
            
            echo '<script>
                  window.location="main.php";
             </script>';
            exit();
        }
        
       

    }
?>
        
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                
            </header>
            <article>
                <h1>Iniciar Sesión</h1>
                <form name="LogIn" method="post" action="login.php">
                    <label>Usuario:</label>
                    <input type="text" name="user" id="user" required><br><br>
                    <label>Contraseña:</label>
                    <input type="password" name="pass" id="pass" required><br><br>
                    <input type="radio" name="salvar" id="salvar1" value="saveusu">Guardar usuario<br>
                    <input type="radio" name="salvar" id="salvar2" value="saveusupass">Guardar Usuario y Contraseña<br>
                    <input type="radio" name="salvar" id="salvar3" value="nosave">No guardar nada<br><br>
                    <label>¿No estas registrado?</label><a href="registro.php">Registrate</a><br><br>
                    <input type="submit" value="Aceptar" class="boton" name="aceptar">
                    <input type="reset" value="Cancelar" class="boton">
                    <input type="button" value="Volver" class="boton" onclick="volvermain()">
                </form>
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        
<?php
    $cont=0;
    if(empty($_SESSION["usuario"])){
        if(!empty($_COOKIE["radioCarShopPHP"])){
            if(!empty($_COOKIE["usuarioCarShopPHP"])){
                $user=$_COOKIE["usuarioCarShopPHP"];
            }
            if(!empty($_COOKIE["contraCarShopPHP"])){
                $pass=$_COOKIE["contraCarShopPHP"];
            }
            $radio=$_COOKIE["radioCarShopPHP"];
            switch($radio){
                case "saveusu":?>
                    <script>
                        document.getElementById("user").value="<?php echo $user; ?>";
                        document.getElementById("pass").value="";
                        document.getElementById("salvar1").checked=true;
                    </script>
                <?php
                break;
                case "saveusupass":?>
                    <script>
                        document.getElementById("user").value="<?php echo $user; ?>";
                        document.getElementById("pass").value="<?php echo $pass; ?>";
                        document.getElementById("salvar2").checked=true;
                    </script>
                <?php
                default:?>
                    <script>
                        document.getElementById("user").value="";
                        document.getElementById("pass").value="";
                        document.getElementById("salvar3").checked=true;
                    </script>
                <?php
                break;
            }
        }
    }
?>
        
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>

