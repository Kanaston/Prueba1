<?php
    session_start();
    if(!isset($_SESSION["usuario"])){
               echo"<script>
               window.location='error.php';
            </script> ";
    }
    elseif($_SESSION["usuario"]!="admin")
        echo"<script>
               window.location='menu.php';
            </script> ";
   
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="imagenes/electronicc.png" type="image/png">
        <title>Registro</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"> <img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                <input type="text" class=titulo placeholder="Buscar articulo...">
            </header>
            <article>
                <form action="menuAdmin.php" method="post">
                    <input type="submit" value="Agregar un producto" name="add"><br>
                    <div class="articulos">
                        <?php
                            include('BaseD.php');
                            include("conexion.php");
                            try{
                                $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
                                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                for($i=1;$i<100;$i++){
                                    $query="SELECT * FROM $BDName.producto where idproducto=$i";
                                    $getUsers = $conn->prepare($query);
                                    $getUsers->execute();
                                    $users = $getUsers->fetchAll();
                                    foreach ($users as $user) {
                                        echo '<img src="'.$user['foto'].'" class="produc"><br>';
                                        $id=$user['idproducto'];
                                        echo $user['nombre'];
                                        echo "<br>";
                                        echo $user['descripcion'];
                                        echo "<br>";
                                        echo "Cantidad:".$user['cantidad']."<br>";
                                        echo "$".$user['precio']."<br>";
                                        ?>
                                            <input type="submit" value="Modificar un producto" name="mod"><br>
                                            <input type="submit" value="Dar de baja un producto" name="del"><br>
                                        <?php
                                        echo "<br>";
                                    }
                                }
                            }
                            catch(PDOException $e){
                                echo "Error: " . $e->getMessage();
                            }
                        ?>
                    </div>
                </form>
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>

<?php
    if(isset($_POST["add"])){
        echo '<script>
        window.location="prodreg.php";
    </script>';
    }
    if(isset($_POST["mod"])){
        setcookie("idmod", $id, time() + (86400 * 30));
        echo '<script>
        window.location="ModificarProducto.php";
    </script>';
    }
    if(isset($_POST["del"])){
        $into="'status'='B'";
        $values="'idproducto'='$id'";
        modifyDB("producto",$into,$values);
        header("Refresh:0"); 
    }
?>

<?php
    if(!empty($_COOKIE["usuario".$_SESSION["usuario"]])){
        if(!empty($_COOKIE["letra".$_SESSION["usuario"]])){
            switch($_COOKIE["letra".$_SESSION["usuario"]]){
                case "Chico":?>
                    <style>
                        article{
                            font-size: 10px;
                        }
                    </style>
                    <?php
                break;
                case "Mediano":?>
                    <style>
                        article{
                            font-size: 20px;
                        }
                    </style>
                    <?php
                break;
                case "Grande":?>
                    <style>
                        article{
                            font-size: 30px;
                        }
                    </style>
                    <?php
                break;
            }
        }
        if(!empty($_COOKIE["fondo".$_SESSION["usuario"]])){?>
            <style>
                body{
                    background-color: <?php echo $_COOKIE["fondo".$_SESSION["usuario"]] ?>;
                }
            </style>
            <?php
        }
        if(!empty($_COOKIE["colletra".$_SESSION["usuario"]])){?>
            <style>
                body{
                    color: <?php echo $_COOKIE["colletra".$_SESSION["usuario"]] ?>;
                }
            </style>
            <?php
        }
        if(!empty($_COOKIE["header".$_SESSION["usuario"]])){?>
            <style>
                header{
                    background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                }
                footer{
                    background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                }
            </style>
            <?php
        }
    }
?>