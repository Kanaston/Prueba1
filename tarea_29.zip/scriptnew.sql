-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema bd_carritocompras
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema bd_carritocompras
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `bd_carritocompras` DEFAULT CHARACTER SET utf8mb4 ;
USE `bd_carritocompras` ;

-- -----------------------------------------------------
-- Table `bd_carritocompras`.`producto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_carritocompras`.`producto` (
  `idproducto` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `descripcion` VARCHAR(256) NOT NULL,
  `precio` DECIMAL(10,0) NOT NULL,
  `cantidad` INT(11) NOT NULL,
  `foto` VARCHAR(256) NOT NULL,
  `estatus` VARCHAR(1) NOT NULL,
  PRIMARY KEY (`idproducto`))
ENGINE = InnoDB
AUTO_INCREMENT = 11
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `bd_carritocompras`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_carritocompras`.`user` (
  `idusuario` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `user` VARCHAR(45) NOT NULL,
  `pass` VARCHAR(45) NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `edad` INT(11) NOT NULL,
  `estatus` VARCHAR(1) NOT NULL,
  `confirmacion` INT(4) NOT NULL,
  PRIMARY KEY (`idusuario`))
ENGINE = InnoDB
AUTO_INCREMENT = 17
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `bd_carritocompras`.`carrito`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_carritocompras`.`carrito` (
  `idcarrito` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `idusuario` BIGINT(20) NOT NULL,
  `idproducto` BIGINT(20) NOT NULL,
  `cantidad` INT(11) NOT NULL,
  `precio` DECIMAL(10,0) NOT NULL,
  `estatus` VARCHAR(1) NOT NULL,
  PRIMARY KEY (`idcarrito`),
  INDEX `carrito_product_idx` (`idproducto` ASC) VISIBLE,
  INDEX `carrito_user_idx` (`idusuario` ASC) VISIBLE,
  CONSTRAINT `carrito_product`
    FOREIGN KEY (`idproducto`)
    REFERENCES `bd_carritocompras`.`producto` (`idproducto`),
  CONSTRAINT `carrito_user`
    FOREIGN KEY (`idusuario`)
    REFERENCES `bd_carritocompras`.`user` (`idusuario`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `bd_carritocompras`.`detalleventas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_carritocompras`.`detalleventas` (
  `iddetalleventas` INT(11) NOT NULL AUTO_INCREMENT,
  `idventas` INT(11) NOT NULL,
  `idproducto` INT(11) NOT NULL,
  `cantidad` INT(11) NOT NULL,
  PRIMARY KEY (`iddetalleventas`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8mb4
COMMENT = '								';


-- -----------------------------------------------------
-- Table `bd_carritocompras`.`ventas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_carritocompras`.`ventas` (
  `idventas` INT(11) NOT NULL AUTO_INCREMENT,
  `idusuario` INT(11) NOT NULL,
  `preciototal` FLOAT NOT NULL,
  `fecha` DATETIME NOT NULL,
  `modificacion` DATETIME NULL DEFAULT NULL,
  `estatus` VARCHAR(1) NOT NULL,
  PRIMARY KEY (`idventas`))
ENGINE = InnoDB
AUTO_INCREMENT = 6
DEFAULT CHARACTER SET = utf8mb4;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
