

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="imagenes/electronicc.png" type="image/png">
        <title>Comercial Network</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    
    <form name="main" method="post" action="Consultas.php">
    <body>
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                <p>Consultas</p>
                 
            </article>
            <footer>
              
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <br>
                
            </footer>
            <input type="submit" value="Productos Vendidos" name="ProductosVend"><br>
                <input type="submit" value="Productos que generan mas Ingresos" name="ProductosIng"><br>
                <input type="submit" value="Clientes que compran mas productos" name="ClientesProd"><br>
                <input type="submit" value="Clientes que generan mas ingresos" name="ClientesIng"><br>
                <input type="submit" value="Ventas" name="Ventas"><br>
              
        <a href="main.php">Regresar</a>
        </div>
         
            </form>


            <?php
            include('BaseD.php');
    if(isset($_POST["ProductosVend"])){?>

         
    <table border="1" style="margin: 100px;" >
    <tr>
        <th>Id </th>
        <th>Nombre</th>
        <th>Cantidad</th>
     
    </tr>
    <?php

$datos = ProductosMasVendidos();

foreach ($datos as $dato) {

echo "<tr>
        <td>".$dato['idproducto']."</td>
        <td>".$dato['nombre']."</td>
        <td>".$dato['cantidad']."</td>
    
     
    </tr>";}
    ?>
    </table> <?php
    }
    if(isset($_POST["ProductosIng"])){?>
      
    <table border="1" style="margin: 100px;" >
    <tr>
        <th>Id </th>
        <th>Nombre</th>
        <th>Importe</th>
     
    </tr>
    <?php

$datos = ProductosMasIngresos();

foreach ($datos as $dato) {

echo "<tr>
        <td>".$dato['idproducto']."</td>
        <td>".$dato['nombre']."</td>
        <td>".$dato['importe']."</td>
    
     
    </tr>";}
    ?>
    </table> <?php
    }
    if(isset($_POST["ClientesProd"])){?>
     
    <table border="1" style="margin: 100px;" >
    <tr>
        <th>Id </th>
        <th>Nombre</th>
        <th>Cantidad</th>
     
    </tr>
    <?php

$datos = ClientesMasProductos();

foreach ($datos as $dato) {

echo "<tr>
        <td>".$dato['idusuario']."</td>
        <td>".$dato['nombre']."</td>
        <td>".$dato['cantidad']."</td>
    
     
    </tr>";}
    ?>
    </table> <?php
    }
    if(isset($_POST["ClientesIng"])){?>
       <table border="1" style="margin: 100px;" >
    <tr>
        <th>Id </th>
        <th>Nombre</th>
        <th>Ingreso</th>
     
    </tr>
    <?php

$datos = ClientesMasIngresos();

foreach ($datos as $dato) {

echo "<tr>
        <td>".$dato['idusuario']."</td>
        <td>".$dato['nombre']."</td>
        <td>".$dato['ingreso']."</td>
    
     
    </tr>";}
    ?>
    </table> <?php
   }
   if(isset($_POST["Ventas"])){?>
   <?php
}
?>


        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>



