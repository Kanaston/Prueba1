<?php

$codigoConfirmacion = rand(111, 999);
echo $codigoConfirmacion;

?>