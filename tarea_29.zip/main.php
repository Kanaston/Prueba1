<?php
    session_start();
    include('BaseD.php');
    if(isset($_POST["close"])){
        session_destroy();
        header("Refresh:0");    
    }
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="electronicc.png" type="image/png">
        <title>Comercial Network</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                <input type="text" class=titulo placeholder="Buscar articulo...">
                <div class="usuario">
                    <?php
                        $var=checar();
                        switch($var){
                            case 1:
                                logeado($_SESSION["usuario"]);
                            break;
                            case 2:
                                logeado($_SESSION["usuario"]);
                            break;
                            case 0:
                                sinlog();
                            break;
                        }
                    ?>
                </div>
            </header>
            <article>
                <form name="main" method="post" action="main.php">
                    <?php
                        if($var==2){
                            ?>
                                <input type="submit" value="Administrar Productos" name="administrar">
                                <input type="submit" value="Administrar Usuarios" name="adminuser"><br>
                                <input type="submit" value="Registro de ventas" name="ventas"><br>
                            <?php
                        }
                    ?>
                      <?php
                        $var=checar();
                        if($var==1||$var==2){?>
                            <input type="submit" value ="Modificar usuario" name="modificar">
                            <input type="submit" value="Cerrar Sesión" name="close">
                        <?php
                        }
                    ?>
                    </form>
                    <div class="articulos">
                        <?php
                            verprod();
                        ?>
                    </div>
                    <br>
                    
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>

<?php
    if(isset($_POST["agregar"])){
        if($var==2){
            $iduser=1;    
        }
        else{
            $iduser=getiduser($_SESSION["usuario"]);
        }
        $producto = obtenerProducto($_POST["idprod"]);
        $precio = $producto['precio'];
        $into="idusuario,idproducto,cantidad,precio,status";
        $values="'".$iduser."','".$_POST["idprod"]."','1','".$precio."','A'";
        insertDB("carrito",$into,$values);
        echo '<script>alert("Producto agregado al carrito con exito");</scrpit>';
    }
?>

<?php
    if(isset($_POST["administrar"])){
       echo "<script> window.location='menuAdmin.php';
       </script>";
    }
    if(isset($_POST["adminuser"])){
         echo "<script> window.location='MenuAdministrador.php';
       </script>";
    }
    if(isset($_POST["ventas"])){
         echo "<script> window.location='RegistroVentasUsuario.php';
       </script>";
    }
    if(isset($_POST["modificar"])){
        echo"<script> window.location='configurarUser.php';
        </script>
        ";
    }
?>

<?php
    function checar(){
        if (isset($_SESSION["usuario"])){
            if($_SESSION["usuario"]=="admin"){
                return 2;
            }
            else{
                return 1;
            }
        }
        else{
            return 0;
        }
    }
?>

<?php
    function logeado($nombre){
        echo "Bienvenido ".$nombre; ?>
        <a href="carrito.php"><img src="imagenes/carrito.png" style="width:40px; heigth:28px" class="carrito"></a>
    <?php
    }
?>

<?php
    function sinlog(){
    ?>
        <a href="registro.php" class="enlace">Registrarse</a>
        <a href="login.php" class="enlace">Iniciar Sesión</a>
    <?php
    }
?>

<?php
    if(checar()==1){
        if(!empty($_COOKIE["usuario".$_SESSION["usuario"]])){
            if(!empty($_COOKIE["letra".$_SESSION["usuario"]])){
                switch($_COOKIE["letra".$_SESSION["usuario"]]){
                    case "Chico":?>
                        <style>
                            article{
                                font-size: 10px;
                            }
                        </style>
                        <?php
                    break;
                    case "Mediano":?>
                        <style>
                            article{
                                font-size: 20px;
                            }
                        </style>
                        <?php
                    break;
                    case "Grande":?>
                        <style>
                            article{
                                font-size: 30px;
                            }
                        </style>
                        <?php
                    break;
                }
            }
            if(!empty($_COOKIE["fondo".$_SESSION["usuario"]])){?>
                <style>
                    body{
                        background-color: <?php echo $_COOKIE["fondo".$_SESSION["usuario"]] ?>;
                    }
                </style>
                <?php
            }
            if(!empty($_COOKIE["colletra".$_SESSION["usuario"]])){?>
                <style>
                    body{
                        color: <?php echo $_COOKIE["colletra".$_SESSION["usuario"]] ?>;
                    }
                </style>
                <?php
            }
            if(!empty($_COOKIE["header".$_SESSION["usuario"]])){?>
                <style>
                    header{
                        background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                    }
                    footer{
                        background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                    }
                </style>
                <?php
            }
        }
    }
?>