<?php
    session_start();
    if(!isset($_SESSION["usuario"])){
        echo '<script>
                window.location="error.php";
            </script>';
    }

    include('BaseD.php');

    if(isset($_POST["comprar"])){
        $DatosUsuario=ObtenerUsuario($_SESSION["usuario"]);
        $iduser= $DatosUsuario['idusuario'];
        

        //guardar encabezado de ventas
        $table = "ventas";   
        $into="idusuario, preciototal, fecha, modificacion, estatus";
        $values="'".$iduser."', ".$_POST["total"].",now(),null,'A'";
        $idventa = insertDB($table,$into,$values);

        //guardar detalle de venta
        $datos = ObtenerCarrito($iduser);
        foreach ($datos as $dato) {
            $table = "detalleventas";   
            $into="idventas, idproducto, cantidad";
            $values=$idventa.", ".$dato['idproducto'].", ".$dato['cantidad'];
            insertDB($table,$into,$values);

        }

        //borrar carrito temporal
        $condicion="idusuario=$iduser";
        deleteDB("carrito", $condicion);
        header("Refresh:0");
    }
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <title>Carrito de compras</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div>
            <header>
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                <input type="text" class=titulo placeholder="Buscar articulo...">
                <div class="usuario">
                    <?php
                        $var=checar();
                        if($var==1){
                            logeado();
                        }
                        else{
                            sinlog();
                        }
                    ?>
                </div>
            </header>
            <article>
            <div class="articulos">
                    <?php

                        $con=1;
                        try{
                            $total= 0;
                            $DatosUsuario=ObtenerUsuario($_SESSION["usuario"]);
                            $idUsuario= $DatosUsuario['idusuario'];
                            $datos = ObtenerCarrito($idUsuario);
                            foreach ($datos as $dato) {
                                echo  '<form name="carrito" method="post" action="carrito.php">'; 
                                echo '<img src="imagenes/'.$dato['foto'].'" class="produc"><br>';
                                $id=$dato['idproducto'];
                                echo $dato['nombre']."<br>";
                                echo $dato['descripcion']."<br>";
                                echo "Cantidad: ";
                                ?> 
                                    <input type="text" value="<?php echo $dato['cantidad']; ?>" name="cantidad" id="cantidad" disabled>
                                <?php
                                echo "<br>";
                                echo "Precio: ";
                                ?> 
                                    <input type="text" value="<?php echo $dato['precio'] ?>" id="precio" name="precio" disabled>
                                    <input type="hidden" value="<?php echo $dato['idcarrito'] ?>" id="idcarrito" name="idcarrito" >
                                <?php
                                echo "<br>";
                                ?>
                                    <input type="submit" value="Eliminar del carrito" name="delete">
                                <?php
                                $total=$total+$dato['precio'];
                                $con++;
                                 

                                echo '</form>';
                            }
                            echo "Total a pagar:". $total; 
                        }
                        catch(PDOException $e){
                            echo "Error: " . $e->getMessage();
                        }
                      ?>
                        

                        
                    <form name="Comprar" method="post" action="carrito.php">
                        <input type="hidden" name="total" value="<?php echo $total; ?>">
                        <input type="submit" name="comprar" value="Comprar">
                    </form>
                </div> 
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.html" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>

<?php
    if(isset($_POST["delete"])){
        $condicion="('idusuario'='$iduser') and ('idproducto'='$id')";
        deleteDB("carrito", $condicion);
    }
    
?>

<?php
    function checar(){
        if (isset($_SESSION["usuario"])){
            return 1;
        }
        else{
            return 0;
        }
    }
?>

<?php
    function logeado(){
        echo "Bienvenido ".$_SESSION["usuario"]; ?>
        <a href="carrito.php"><img src="imagenes/carrito.png" style="width:40px; heigth:28px" class="carrito"></a>
    <?php
    }
?>

<?php
    function sinlog(){
    ?>
        <a href="registro.php" class="enlace">Registrarse</a>
        <a href="login.php" class="enlace">Iniciar Sesión</a>
    <?php
    }
?>


<?php
    if(isset($_POST["save"])){
        $letra=$_POST["tamanioletra"];
        $col_fondo=$_POST["fondo"];
        $col_letra=$_POST["letra"];
        $col_headfoot=$_POST["cabeza"];
        for($i=1;$i<100;$i++){
            if($_COOKIE["usuario".$i]==$_SESSION["usuario"]){
                setcookie("letra".$i,$letra,time()+ (86400 * 30),"/");
                setcookie("fondo".$i,$col_fondo,time()+ (86400 * 30),"/");
                setcookie("colletra".$i,$col_letra,time()+ (86400 * 30),"/");
                setcookie("header".$i,$col_headfoot,time()+ (86400 * 30),"/");
                header("refresh:0");
                break;
            }
        }
    }
    if(isset($_POST["delete"])){
        for($i=1;$i<100;$i++){
            if(!empty($_COOKIE["usuario".$i])){
                setcookie("letra".$i,"",-time()+ (86400 * 30),"/");
                setcookie("fondo".$i,"",-time()+ (86400 * 30),"/");
                setcookie("colletra".$i,"",-time()+ (86400 * 30),"/");
                setcookie("header".$i,"",-time()+ (86400 * 30),"/");
            }
        }
    }
?>

<?php
    if(checar()==1){
        if(!empty($_COOKIE["usuario".$_SESSION["usuario"]])){
            if(!empty($_COOKIE["letra".$_SESSION["usuario"]])){
                switch($_COOKIE["letra".$_SESSION["usuario"]]){
                    case "Chico":?>
                        <style>
                            article{
                                font-size: 10px;
                            }
                        </style>
                        <?php
                    break;
                    case "Mediano":?>
                        <style>
                            article{
                                font-size: 20px;
                            }
                        </style>
                        <?php
                    break;
                    case "Grande":?>
                        <style>
                            article{
                                font-size: 30px;
                            }
                        </style>
                        <?php
                    break;
                }
            }
            if(!empty($_COOKIE["fondo".$_SESSION["usuario"]])){?>
                <style>
                    body{
                        background-color: <?php echo $_COOKIE["fondo".$_SESSION["usuario"]] ?>;
                    }
                </style>
                <?php
            }
            if(!empty($_COOKIE["colletra".$_SESSION["usuario"]])){?>
                <style>
                    body{
                        color: <?php echo $_COOKIE["colletra".$_SESSION["usuario"]] ?>;
                    }
                </style>
                <?php
            }
            if(!empty($_COOKIE["header".$_SESSION["usuario"]])){?>
                <style>
                    header{
                        background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                    }
                    footer{
                        background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                    }
                </style>
                <?php
            }
        }
    }

?>