<?php
    $Server="localhost";
    $User="id12464920_carrito";
    $Pass="kqbXrU6ZF)ei%Q8Y";
    $BDName="id12464920_bd_carritocompras";
?>