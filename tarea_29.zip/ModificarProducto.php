<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="electronicc.png" type="image/png">
        <title>Modificar producto</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        
<?php
    include("conexion.php");
    //Datos de conexión
    $con=mysqli_connect($Server,$User,$Pass,$BDName)or die ("problemas al conectar");

        
    if(isset($_POST["confirmar"])){
        //Necesitamos establecer una conexión con la base de datos.
 
    
        if (isset($_POST["nombre"], $_POST["descripcion"], $_POST["precio"],
        $_POST["cantidad"], $_POST["foto"], $_POST["estatus"]))
            {
                //traspasamos a variables locales, para evitar complicaciones con las comillas:
                $IdProducto = $_POST["idproducto"];
                $Nombre = $_POST["nombre"];
                $Descripcion = $_POST["descripcion"];
                $Precio = $_POST["precio"];
                $Cantidad = $_POST["cantidad"];
                $Foto = $_POST["foto"];
                $Estatus = $_POST["estatus"];

                $consulta = "UPDATE producto 
                SET nombre='$Nombre',descripcion='$Descripcion',precio='$Precio',cantidad='$Cantidad',
                foto='$Foto',estatus='$Estatus' WHERE idproducto=$IdProducto";
                echo $consulta;
                die ("deiekeke");

                //Aqui ejecutaremos esa orden
                $res = mysqli_query($con, $consulta);
                mysqli_close($con);

                if ($res)
                {
                    header('Location: MenuAdministrador.php');
                    exit();
                } else {
                    echo "<script>alert('Datos erroneos, confirme que sus datos esten correctos')</script>";
                }

                // $tabla="user";
                // $into="'user'='".$_POST['usuario']."','pass'='".$_POST['contra']."','nombre'='".$_POST['nombre']."','email'='".$_POST['email']."','edad'='".$_POST['edad']."','status'='".$_POST['status']."'";
                // $values="'idusuario'='".$IdUsuario."'";
                // modifyDB($tabla,$into,$values);

            }else {
                echo "<script>alert('Datos incompletos')</script>";
            }
        } else {
            //cargar los datos
            $IdProducto = $_GET["id"];

            echo $consulta;
            $consulta = "SELECT * FROM producto WHERE idusuario=$IdProducto";
            //Ejecutar la consulta

            echo $con;
            
            die("*****die****"); 
            $resultado = mysqli_query($con, $consulta) or die(mysqli_error());
            $datos = mysqli_fetch_array($resultado);
            mysqli_close($con);
       }
        

?>
    
    <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
              
            </header>
            <article>
                <h1>Registro de productos</h1>
                <form class="" action="prodreg.php" method="post" id="main">
                    <strong><label for="">Nombre:</label></strong><br>
                    <input type="text" id="nombre" name="nombre" value="<?php echo $datos["nombre"]; ?>" required pattern="^[A-Za-z1-9]+$" maxlength="35" minlength="1"
                    title="Sin espacios, letras, números, al menos 1 caracter">
                    <br><br>
                    <strong><label for="">Descripcion:</label></strong><br>
                    <input type="textarea" id="descripcion" name="descripcion" value="<?php echo $datos["descripcion"]; ?>" required pattern="^[A-Za-z0-9\.+-*_:;,¿¡?!|°]+$" minlength="8"
                    title="Combinar letras, al menos un número, al menos un símbolo especial, al menos 8 caracteres">
                    <br><br>
                    <strong><label for="">Precio:</label></strong><br>
                    <input type="number" id="precio" name="precio" value="<?php echo $datos["precio"]; ?>" required min="1" step="any"><br><br>
                    <strong><label for="">Cantidad:</label></strong><br>
                    <input type="number" id="cantidad" name="cantidad" value="<?php echo $datos["cantidad"]; ?>" required min=1><br><br>
                    <strong><label for="">foto:</label></strong><br>
                    <input type="file" name="foto" id="foto" value="<?php echo $datos["foto"]; ?>" required><br><br>
                    <strong><label for="">Estatus:</label></strong><br>
                    <input type="file" name="estatus" id="estatus" value="<?php echo $datos["estatus"]; ?>" required><br><br>
                    
                    <br>
                    <input type="submit" value="Confirmar" name="confirmar">
                    <input type="submit" value="Cancelar" name="volver">
                    <input type="reset" value="Reset">
                </form>
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
    </html>
