<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="electronicc.png" type="image/png">
        <title>Registro</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        
<?php
    if(isset($_POST["accion"])){
        include('BaseD.php');
        $confirmacion = getuserRegistro($_POST["user1"]);

        if($confirmacion == 0){
            $codigoConfirmacion = rand(1111, 9999);
            
            $tabla="user";
            $into = "user, pass, nombre, email, edad,estatus, confirmacion";
            $values = "'".$_POST["user1"]."','".$_POST["contra"]."','".$_POST["nom"]."','".$_POST["correo"]."','".$_POST["edad"]."', 'A', '" .$codigoConfirmacion."'";
            insertDB($tabla,$into,$values);
            // //mandar correo confirmación
            $destino=$_POST["correo"];
            $nombre = $_POST["nom"];
            $mensaje = $_POST["user1"] . " se registró correctamente en nuestro sistema. Debe ingresar y proporcionar el siguiente código para confirmar esta cuenta: " . $codigoConfirmacion;
            $contenido = "Nombre: ". $nombre ."\nMensaje: " . $mensaje;
            $enviar=mail($destino,"Contacto", $contenido);
            if ($enviar == true){
                echo '<script>
                window.location="login.php";
            </script>';
                exit();
            }
        }
        else
        {
            echo '<script>
                alert("Este usuario ya existe");
                window.history.back();
            </script>';
        }
    }
?>
    
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                
            </header>
            <article>
                <h1>Registro</h1>
                <form class="" action="registro.php" method="post" id="main" onsubmit="return validarContra();">
                    <strong><label for="">Nombre:</label></strong><br>
                    <input type="text" id="nom" name="nom" required pattern="^[A-Za-z ]+$" maxlength="35" minlength="1"
                    title="Solo letras"><br><br>
                    <strong><label for="">Edad:</label></strong><br>
                    <input type="number" id="edad" name="edad" min="18" max="100" required><br><br>
                    <strong><label for="">Correo electronico:</label></strong><br>
                    <input type="text" id="email" name="correo" required pattern="^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$" maxlength="35" minlength="6"><br><br>
                    
                    <strong><label for="">Usuario:</label></strong><br>
                    <input type="text" id="user1" name="user1" required pattern="^[A-Za-z1-9]+$" maxlength="35" minlength="1"
                    title="Sin espacios, letras, números, al menos 5 caracteres">
                    <br><br>
                    <strong><label for="">Contraseña:</label></strong><br>
                    <input type="password" id="contra" name="contra" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                    title="Combinar letras, al menos un número, al menos un símbolo especial, al menos 8 caracteres"><br><br>
                    <input type="checkbox" id="checpass" onchange="mostrarpass()">Mostrar Contraseña
                    <br><br>
                    <strong><label for="">Confirmar Contraseña:</label></strong><br>
                    <input type="password" id="confirmarContra" name="confirmarContra" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                    title="Combinar letras, al menos un número, al menos un símbolo especial, al menos 8 caracteres"><br><br>
                    
                    <input type="checkbox" id="checpass" onchange="mostrarConfirmacion()">Mostrar Contraseña
                    <br><br>

                    <input type="hidden" value="Confirmar" id="accion" name="accion" >
                    <input type="submit" value="Confirmar" name="confirmar" >
                    <input type="button" value="Cancelar" onclick="volverlogin()">
                    <input type="reset" value="Reset" name="reset">
                </form>
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>
