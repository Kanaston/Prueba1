<?php
    //Necesitamos establecer una conexión con la base de datos.
    include("conexion.php");
    //Datos de conexión
    $con=mysqli_connect($Server,$User,$Pass,$BDName)or die ("problemas al conectar");

    $idusuario = $_GET["id"];
    $consulta = "DELETE FROM user WHERE idusuario=$idusuario";
    $resultado = mysqli_query($con, $consulta) or die(mysqli_error());

    header("location: MenuAdministrador.php");
?>