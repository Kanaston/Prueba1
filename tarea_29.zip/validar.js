function volvermain(){
    window.location.replace("main.php");
}

function volverlogin(){
    window.location.replace("login.php");
}

function mostrarpass(){
    if(document.getElementById("contra").type=="password"){
        document.getElementById("contra").type="text";
    }
    else{
        document.getElementById("contra").type="password";
    }
}
function mostrarConfirmacion(){
    if(document.getElementById("confirmarContra").type=="password"){
        document.getElementById("confirmarContra").type="text";
    }
    else{
        document.getElementById("confirmarContra").type="password";
    }
}
function validarContra(){
  if( document.getElementById("contra").value!=document.getElementById("confirmarContra").value){
    alert("confirmar contraseña, no son iguales contraseña y confirmacion");
    return false;
    
  }
  return true;
}




function valemail(valor){
    if (/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(valor)){
        return true;
    } 
    else {
        return false;
    }
}

function valcon(){
    const input = document.getElementById("nam");
    var con=0;
    if(!input.checkValidity()) {
        con=con+1;
    }
    const input2 = document.getElementById("men");
    if(!input2.checkValidity()) {
        con=con+1;
    }
    var correo = valemail(document.getElementById("mail").value);
    if(correo==false){
        con=con+1;
    }
    if(con>0){
        return 1;
    }
    return 0;
}

function mostrar(){
    var numero=0;
    numero = numero + valcon();
    if (numero==0){
        alert("Nombre:"+document.getElementById("nam").value+"\nCorreo: "+document.getElementById("mail").value+"\nMensaje: "+document.getElementById("men").value);
    }
}

function chico(){
    document.getElementById("letrasize").style.fontSize="10px";
}

function mediano(){
    document.getElementById("letrasize").style.fontSize="20px";
}

function grande(){
    document.getElementById("letrasize").style.fontSize="40px";
}

function colorfondo(){
    document.getElementById("cuerpo").style.backgroundColor=document.getElementById("colfondo").value;
}

function colorletra(){
    document.getElementById("letracolor").style.color=document.getElementById("colletra").value;
}

function colpies(){
    document.getElementById("cabeza").style.backgroundColor=document.getElementById("pie").value;
    document.getElementById("pies").style.backgroundColor=document.getElementById("pie").value;
}

function carritocant(precio){
    num = document.getElementById("cant").value; 
    precio= num*precio;
    document.getElementById("price").value=precio;
}