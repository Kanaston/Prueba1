<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="electronicc.png" type="image/png">
        <title>Registro</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        
<?php
    include("conexion.php");
    //Datos de conexión
    $con=mysqli_connect($Server,$User,$Pass,$BDName)or die ("problemas al conectar");

        
    if(isset($_POST["confirmar"])){
        //Necesitamos establecer una conexión con la base de datos.
 
    
        if (isset($_POST["nombre"], $_POST["edad"], $_POST["correo"],
        $_POST["usuario"], $_POST["contra"], $_POST["confirmarContra"], $_POST["estatus"]))
            {
                //traspasamos a variables locales, para evitar complicaciones con las comillas:
                $IdUsuario = $_POST["idusuario"];
                $Usuario = $_POST["usuario"];
                $Contra = $_POST["contra"];
                $Nombre = $_POST["nombre"];
                $Email = $_POST["correo"];
                $Edad = $_POST["edad"];
                $Estatus = $_POST["estatus"];

                $consulta = "UPDATE user 
                SET user='$Usuario',pass='$Contra',nombre='$Nombre',email='$Email',
                edad='$Edad',estatus='$Estatus'WHERE idusuario=$IdUsuario";
        
                //Aqui ejecutaremos esa orden
                $res = mysqli_query($con, $consulta);
                mysqli_close($con);
// echo $consulta;
// die ("deiekeke");

                if ($res)
                {
                    header('Location: MenuAdministrador.php');
                    exit();
                } else {
                    echo "<script>alert('Datos erroneos, confirme que sus datos esten correctos')</script>";
                }

                // $tabla="user";
                // $into="'user'='".$_POST['usuario']."','pass'='".$_POST['contra']."','nombre'='".$_POST['nombre']."','email'='".$_POST['email']."','edad'='".$_POST['edad']."','status'='".$_POST['status']."'";
                // $values="'idusuario'='".$IdUsuario."'";
                // modifyDB($tabla,$into,$values);

            }else {
                echo "<script>alert('Datos incompletos')</script>";
            }
        } else {
            //cargar los datos
            $IdUsuario = $_GET["id"];
            $consulta = "SELECT * FROM user WHERE idusuario=$IdUsuario";
            //Ejecutar la consulta
            $resultado = mysqli_query($con, $consulta) or die(mysqli_error());
            $datos = mysqli_fetch_array($resultado);
            mysqli_close($con);
        }
        

?>
    
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                
            </header>
            <article>
                <h1>Modificar Usuario</h1>
                <form class="" action="ModificarUsuario.php" method="post" id="main" onsubmit="return validarContra();">
                    
                <input type="hidden" name="guardar" value="2" />
                <input type="hidden" name="idusuario" value="<?php echo $_GET["id"]; ?>" />
            
                    
                    <strong><label for="">Nombre:</label></strong><br>
                    <input type="text" id="nombre" name="nombre" pattern="^[A-Za-z ]+$" maxlength="35" minlength="1"
                    title="Solo letras" value="<?php echo $datos["nombre"]; ?>" required><br><br>
                    <strong><label for="">Edad:</label></strong><br>
                    <input type="number" id="edad" name="edad" min="18" max="100" value="<?php echo $datos["edad"]; ?>" required><br><br>
                    <strong><label for="">Correo electronico:</label></strong><br>
                    <input type="text" id="correo" name="correo"  value="<?php echo $datos["email"]; ?>" required pattern="^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$" maxlength="35" minlength="6"><br><br>
                    
                    <strong><label for="">Usuario:</label></strong><br>
                    <input type="text" id="usuario" name="usuario" required pattern="^[A-Za-z1-9]+$" maxlength="35" minlength="1"
                    title="Sin espacios, letras, números, al menos 5 caracteres" value="<?php echo $datos["user"]; ?>">
                    <br><br>
                    <strong><label for="">Contraseña:</label></strong><br>
                    <input type="password" id="contra" name="contra" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                    title="Combinar letras, al menos un número, al menos un símbolo especial, al menos 8 caracteres" value="<?php echo $datos["pass"]; ?>" required><br><br>
                    <input type="checkbox" id="checpass" onchange="mostrarpass()">Mostrar Contraseña
                    <br><br>
                    <strong><label for="">Confirmar Contraseña:</label></strong><br>
                    <input type="password" id="confirmarContra" name="confirmarContra" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                    title="Combinar letras, al menos un número, al menos un símbolo especial, al menos 8 caracteres" value="<?php echo $datos["pass"]; ?>" required><br><br>
                    <strong><label for="">Estatus:</label></strong><br>
                    <input type="text" id="estatus" name="estatus" required pattern="^[A-Z]+$" maxlength="1" minlength="1"
                    title="Solo una letra" value="<?php echo $datos["estatus"]; ?>">
                    <br><br>

                    <input type="checkbox" id="checpass" onchange="mostrarConfirmacion()">Mostrar Contraseña
                    <br><br>

                    <input type="hidden" value="Confirmar" id="accion" name="accion" >
                    <input type="submit" value="Confirmar" name="confirmar" >
                    <input type="button" value="Cancelar" onclick="volverlogin()">
                    <input type="reset" value="Reset" name="reset">
                </form>
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>
