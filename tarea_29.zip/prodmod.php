<?php
    session_start();
    if(!isset($_SESSION["usuario"])){
        echo '<script>
        window.location="error.php";
    </script>';
    }
    elseif($_SESSION["usuario"]!="admin")
    echo '<script>
    window.location="main.php";
</script>';
    
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="electronicc.png" type="image/png">
        <title>Registro</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="imagenes/Anotación 2020-03-21 115312.png" class="logo"></a>
                <input type="text" class=titulo placeholder="Buscar articulo...">
            </header>
            <article>
                <h1>Modificar de productos</h1>
                <form class="" action="prodmod.php" method="post" id="main">
                    <?php
                        include('BaseD.php');
                        $Server="localhost";
                        $User="id12464920_carrito";
                        $Pass="kqbXrU6ZF)ei%Q8Y";
                        $BDName="id12464920_bd_carritocompras";
                        try{
                            $conn=new PDO("mysql:host=$Server;dbname=$BDName",$User,$Pass);
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            $idmod=$_COOKIE["idmod"];
                            $query="SELECT * FROM $BDName.producto where idproducto=$idmod";
                            $getUsers = $conn->prepare($query);
                            $getUsers->execute();
                            $users = $getUsers->fetchAll();
                            foreach ($users as $user) {
                                echo '<img src="'.$user['foto'].'" class="produc"><br>';
                                echo "<br>Nombre:";
                                ?>
                                    <input type="text" value="<?php $user['nombre'] ?>" name="nombre">
                                <?php
                                echo "<br>Descripción:";
                                ?>
                                    <input type="textarea" value="<?php $user['descripcion'] ?>" name="descripcion">
                                <?php
                                echo "<br>Cantidad:";
                                ?>
                                    <input type="number" value="<?php $user['cantidad'] ?>" name="cantidad">
                                <?php
                                echo "<br>Precio: $";
                                ?>
                                    <input type="number" value="<?php $user['precio'] ?>" name="precio">
                                <?php
                                echo "<br>";
                            }
                        }
                        catch(PDOException $e){
                            echo "Error: " . $e->getMessage();
                        }
                    ?>
                    <br>
                    <input type="submit" value="Confirmar" name="confirmar">
                    <input type="submit" value="Cancelar" name="volver">
                    <input type="reset" value="Reset">
                </form>
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>

<?php
    if(isset($_POST["confirmar"])){
        $nom=$_POST["nombre"];
        $des=$_POST["descripcion"];
        $pre=$_POST["precio"];
        $cant=$_POST["cantidad"];
        $into="nombre='$nom',descripcion='$des',precio='$pre',cantidad='$cant'";
        $values="idproducto='$idmod'";
        modifyDB("producto",$into,$values);
    }
    if(isset($_POST["volver"])){
        echo '<script>
        window.location="menuAdmin.php";
    </script>';
    }
?>

<?php
    if(!empty($_COOKIE["usuario".$_SESSION["usuario"]])){
        if(!empty($_COOKIE["letra".$_SESSION["usuario"]])){
            switch($_COOKIE["letra".$_SESSION["usuario"]]){
                case "Chico":?>
                    <style>
                        article{
                            font-size: 10px;
                        }
                    </style>
                    <?php
                break;
                case "Mediano":?>
                    <style>
                        article{
                            font-size: 20px;
                        }
                    </style>
                    <?php
                break;
                case "Grande":?>
                    <style>
                        article{
                            font-size: 30px;
                        }
                    </style>
                    <?php
                break;
            }
        }
        if(!empty($_COOKIE["fondo".$_SESSION["usuario"]])){?>
            <style>
                body{
                    background-color: <?php echo $_COOKIE["fondo".$_SESSION["usuario"]] ?>;
                }
            </style>
            <?php
        }
        if(!empty($_COOKIE["colletra".$_SESSION["usuario"]])){?>
            <style>
                body{
                    color: <?php echo $_COOKIE["colletra".$_SESSION["usuario"]] ?>;
                }
            </style>
            <?php
        }
        if(!empty($_COOKIE["header".$_SESSION["usuario"]])){?>
            <style>
                header{
                    background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                }
                footer{
                    background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                }
            </style>
            <?php
        }
    }
?>