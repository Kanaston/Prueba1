<?php
    session_start();
    if(!isset($_SESSION["usuario"])){
                echo"<script>
               window.location='error.php';
            </script> ";
    }
    elseif($_SESSION["usuario"]!="admin"){
                echo"<script>
               window.location='main.php';
            </script> ";
    }
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="DisBase.css">
        <link rel="icon" href="electronicc.png" type="image/png">
        <title>Registro</title>
        <meta name="viewport" content="device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    </head>
    <body>
        <div>
            <header>
                <!--Con el logo se puede regresar a la pagina principal-->
                <a href="main.php"><img src="Anotación 2020-03-21 115312.png" class="logo"></a>
                <input type="text" class=titulo placeholder="Buscar articulo...">
            </header>
            <article>
                <h1>Registro de productos</h1>
                <form class="" action="prodreg.php" method="post" id="main">
                    <strong><label for="">nomre:</label></strong><br>
                    <input type="text" id="nomb" name="nom" required pattern="^[A-Za-z1-9]+$" maxlength="35" minlength="1"
                    title="Sin espacios, letras, números, al menos 1 caracter">
                    <br><br>
                    <strong><label for="">descripcion:</label></strong><br>
                    <input type="textarea" id="des" name="desc" required pattern="^[A-Za-z0-9\.+-*_:;,¿¡?!|°]+$" minlength="8"
                    title="Combinar letras, al menos un número, al menos un símbolo especial, al menos 8 caracteres">
                    <br><br>
                    <strong><label for="">precio:</label></strong><br>
                    <input type="number" name="price" required min="1" step="any"><br><br>
                    <strong><label for="">cantidad:</label></strong><br>
                    <input type="number" name="cant" required min=1><br><br>
                    <strong><label for="">foto:</label></strong><br>
                    <input type="file" name="photo" required><br><br>
                    <br>
                    <input type="submit" value="Confirmar" name="confirmar">
                    <input type="submit" value="Cancelar" name="volver">
                    <input type="reset" value="Reset">
                </form>
            </article>
            <footer>
                <!--Para poder entrar a la configuracion debe de estar iniciar sesión antes-->
                <a href="configuracion.php" style="text-decoration: none; color: black;">Configuracion</a><a href="contacto.php" class="separado" style="text-decoration: none; color: black;">Contacto</a>
            </footer>
        </div>
        <script src="validar.js" charset="utf-8"></script>
    </body>
</html>

<?php
    if(isset($_POST["confirmar"])){
        $into="";
        $values="";
        modifyDB("producto",$into,$values);
    }
    if(isset($_POST["volver"])){
        echo"<script>
               window.location='menuAdmin.php';
            </script> ";
    }
?>

<?php
    if(!empty($_COOKIE["usuario".$_SESSION["usuario"]])){
        if(!empty($_COOKIE["letra".$_SESSION["usuario"]])){
            switch($_COOKIE["letra".$_SESSION["usuario"]]){
                case "Chico":?>
                    <style>
                        article{
                            font-size: 10px;
                        }
                    </style>
                    <?php
                break;
                case "Mediano":?>
                    <style>
                        article{
                            font-size: 20px;
                        }
                    </style>
                    <?php
                break;
                case "Grande":?>
                    <style>
                        article{
                            font-size: 30px;
                        }
                    </style>
                    <?php
                break;
            }
        }
        if(!empty($_COOKIE["fondo".$_SESSION["usuario"]])){?>
            <style>
                body{
                    background-color: <?php echo $_COOKIE["fondo".$_SESSION["usuario"]] ?>;
                }
            </style>
            <?php
        }
        if(!empty($_COOKIE["colletra".$_SESSION["usuario"]])){?>
            <style>
                body{
                    color: <?php echo $_COOKIE["colletra".$_SESSION["usuario"]] ?>;
                }
            </style>
            <?php
        }
        if(!empty($_COOKIE["header".$_SESSION["usuario"]])){?>
            <style>
                header{
                    background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                }
                footer{
                    background-color: <?php echo $_COOKIE["header".$_SESSION["usuario"]] ?>;
                }
            </style>
            <?php
        }
    }
?>