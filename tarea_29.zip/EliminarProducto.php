<?php
ob_start();
?>

<?php

        include("conexion.php");
        include("BaseD.php");
        //Datos de conexión
        $con=mysqli_connect($Server,$User,$Pass,$BDName)or die ("problemas al conectar");
        
        $idproducto = $_GET['id'];
        //$IdProducto = $dato['idproducto'];

        
        $consulta = "UPDATE producto
        SET estatus='B'WHERE idproducto=$idproducto";

        //Aqui ejecutaremos esa orden
        $res = mysqli_query($con, $consulta);
        mysqli_close($con);    

        header("location: MenuProductos.php");
?>